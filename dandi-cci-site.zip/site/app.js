// Toggle Mobile Menu
function toggleMenu() {
  document.getElementById("navMenu").classList.toggle("active");
}

// WhatsApp Logic
const openWhatsapp = document.getElementById("openWhatsapp");
const closeWhatsapp = document.getElementById("closeWhatsapp");
const waPopup = document.getElementById("waPopup");
const startWhatsapp = document.getElementById("startWhatsapp");
const waName = document.getElementById("waName");

if (openWhatsapp) {
  openWhatsapp.addEventListener("click", function (e) {
    e.preventDefault();
    waPopup.classList.add("active");
  });
}

if (closeWhatsapp) {
  closeWhatsapp.addEventListener("click", function () {
    waPopup.classList.remove("active");
  });
}

if (startWhatsapp) {
  startWhatsapp.addEventListener("click", function () {
    const name = waName.value.trim();
    if (name === "") {
      waName.style.border = "1px solid red";
      return;
    }
    // Falls back to the default number if the admin dashboard hasn't set one yet.
    const phone = window.__DANDI_WHATSAPP_NUMBER__ || "2348063182224";
    const message = `Hello, my name is ${name}. I want to support your NGO.`;
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
    waPopup.classList.remove("active");
  });
}
